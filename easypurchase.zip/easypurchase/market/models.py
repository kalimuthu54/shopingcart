from django.db import models
class Category (models.Model):
    id_ct=models.CharField(max_length=10,primary_key=True)
    name=models.CharField(max_length=20)
    slug=models.SlugField(max_length=250,unique=True)
    img=models.ImageField(upload_to="Category")
    def __str__(self):
        return self.name
class product(models.Model):
    ct=models.ForeignKey(Category, on_delete=models.CASCADE)
    name=models.CharField(max_length=10)
    price=models.IntegerField(default=0)
    quantity=models.IntegerField(default=0)
    img=models.ImageField(upload_to="pics")
    slug=models.SlugField(max_length=250,unique=True)
