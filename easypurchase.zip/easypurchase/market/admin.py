from django.contrib import admin
from .models import Category,product 
class Category_admin(admin.ModelAdmin):
    list_display=['id_ct','name','slug']
    prepopulated_fields={'slug':('name',)}
class product_admin(admin.ModelAdmin):
    list_display=['ct','name','price','quantity']
    prepopulated_fields={'slug':('name',)}
    list_editable=['price','quantity']
    list_per_page=20
admin.site.register(Category,Category_admin)
admin.site.register(product,product_admin)
