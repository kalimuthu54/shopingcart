from django.conf import settings
from django.core.mail import send_mail
from django.contrib import messages
from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
def homepage(request):
    return render(request,'homepage.html')
def registerpage(request):
    if request.method=='POST':
        username=request.POST['Uname']
        email=request.POST['email']
        password=request.POST['psw']
        repeatpassword=request.POST['psw-repeat']
        if password==repeatpassword:
            if User.objects.filter(username=username).exists():
                messages.info(request,"Username already exixts...!")
                return redirect('registerpage')
            elif User.objects.filter(email=email).exists():
                messages.info(request,"Email-id already exixts...!")
                return redirect('registerpage')
            else:   
                subject='Message from kalimuthu,'
                message='Thanks for Login...'
                emailFrom=settings.EMAIL_HOST_USER
                emailTo=[request.POST['email']]
                a=send_mail(subject,message,emailFrom,emailTo,fail_silently=False)
                if(a==1):
                    user=User.objects.create_user(username=username,email=email,password=password)
                    user.save()
                    return redirect('loginpage')
                else:
                    messages.info(request,"invalid mail.id...!")
                    return redirect('registerpage')
        else:
            messages.info(request,"password is mismatch...!")
            return redirect('registerpage')
    else:
        return render(request,'register.html')
def loginpage(request):
    if request.method=='POST':
        username=request.POST['Uname']
        password=request.POST['Pass']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('/')
        else:
            messages.info(request,"invalid data")
            return redirect ('loginpage')
    else:
        return render (request,'login.html')
def logoutpage(request):
    auth.logout(request)
    return redirect("/")
